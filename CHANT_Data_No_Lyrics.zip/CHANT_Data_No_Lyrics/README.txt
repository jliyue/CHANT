CHANT dataset files

CSV contains 30 individual song transcriptions, a merged table of 4205 events
and 19 columns, and the song metadata. MusicXML, MIDI, and Score PDFs
contain 30 files each. Match files by their shared DG number and SID.

This release omits note-aligned lyrics from the individual CSVs, merged CSV,
MusicXML, and MIDI. The metadata retains lyricist credits. Each song CSV and the merged CSV
use the same 19 columns.

The MusicXML and MIDI files are generated from the CSV transcriptions. They
follow one pass through the recorded event sequence. MIDI uses piano and a
playback tempo of 120 BPM where the metadata provides no tempo. For DG2_SID005,
the MIDI uses 50 BPM as a playback interpretation of Largo. MusicXML represents
the transcription as staff notation. Use the score PDFs for the printed
jianpu notation, repeats, and original layout.

Symbolic timing is derived by summing the CSV durations. Saved onsets differ
on these songs (number of rows): DG1_SID002 (1), DG26_SID031 (62). Saved values remain in the
CSV tables. For DG1–DG9, Onset in Measure is calculated from cumulative durations
relative to the start of each meter section, modulo the bar length in
quarter-note units. DG3_SID007 is in 2/4 at events 1–165, 4/4 at events
166–222, and 2/4 again from event 223. Its symbolic exports use those
change points. Existing CSV Measure and Event values are retained.
MIDI values are calculated from the song's Jianpu key (the pitch of degree 1),
the numbered degree, the octave shift, and the accidental in semitones.
The CSV Pitch column spells that result according to the numbered degree
and its accidental. For DG23_SID018, degree 1 is D and degree 6 is B,
the tonic of B minor. Spoken events in DG14_SID037 have no MIDI pitch.

DG5_SID013 uses 132 BPM as a playback interpretation of 較快，激昂地.
DG6_SID014 uses 104 BPM as a playback interpretation of 雄壯.
DG7_SID017 uses 108 BPM as a playback interpretation of 中等速度，昂奮地.

MIDI phrase markers follow the CSV Phrase End column. The first event and
each event immediately after an END row receive a start marker. Each end
marker sits at the onset of the END event and identifies that whole event
as part of the phrase, including its full duration. A marker can identify
a note or a rest. Markers follow END where the saved Phrase # disagrees.

DG8_SID020 uses 108 BPM as a playback interpretation of 中板.

DG16_SID003 was checked against the printed barlines and re-encoded as 161
events in 56 measures of 2/4. The export uses exact triplet durations.
